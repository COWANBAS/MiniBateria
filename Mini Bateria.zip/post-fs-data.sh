#!/system/bin/sh
MODDIR ${0%/*}

#####################################
#Mini Bateria
resetprop -n ro.config.small_battery true